import streamlit as st
import pandas as pd
import re

# Set page to wide mode at the very beginning
st.set_page_config(layout="wide")

def analyze_keywords(df):
    # Convert all column names to strings
    df.columns = df.columns.astype(str)
    
    # First, handle the unnamed columns
    if any('Unnamed' in col for col in df.columns):
        # Get the first two columns regardless of their exact names
        first_col = df.columns[0]
        second_col = df.columns[1]
        df = df.rename(columns={
            first_col: 'PARTNER_NAME',
            second_col: 'QUERY'
        })
    
    # Ensure required columns exist
    if 'PARTNER_NAME' not in df.columns or 'QUERY' not in df.columns:
        raise ValueError("Required columns 'PARTNER_NAME' and 'QUERY' not found in the Excel file")
    
    # Convert PARTNER_NAME and QUERY to string type
    df['PARTNER_NAME'] = df['PARTNER_NAME'].astype(str)
    df['QUERY'] = df['QUERY'].astype(str)
    
    # Get unique partners for filtering
    partners = sorted(df['PARTNER_NAME'].unique())
    
    # Get the sets of columns
    revenue_cols = []
    rpc_cols = []
    clicks_cols = []
    
    for col in df.columns:
        col_str = str(col).upper()
        if 'NET_REVENUE' in col_str:
            revenue_cols.append(col)
        elif 'RPC' in col_str:
            rpc_cols.append(col)
        elif 'CLICKS' in col_str:
            clicks_cols.append(col)
    
    # Sort columns to ensure they're in the right order
    revenue_cols.sort()
    rpc_cols.sort()
    clicks_cols.sort()
    
    if not revenue_cols:
        raise ValueError("No NET_REVENUE columns found in the Excel file")
    
    # Create date labels for the columns
    dates = []
    for i in range(len(revenue_cols)):
        dates.append(f"Day {i+1}")
    
    return df, dates, revenue_cols, rpc_cols, clicks_cols, partners

def find_duplicate_keywords(df, selected_date, revenue_cols, rpc_cols, clicks_cols, selected_partners):
    # Get the index from the selected date
    day_index = int(selected_date.split()[1]) - 1
    
    # Get the corresponding columns for this index
    revenue_col = revenue_cols[day_index]
    rpc_col = rpc_cols[day_index]
    clicks_col = clicks_cols[day_index]
    
    # Clean and convert data for the selected columns
    df[clicks_col] = pd.to_numeric(df[clicks_col].astype(str).str.replace(',', ''), errors='coerce').fillna(0)
    df[rpc_col] = pd.to_numeric(df[rpc_col].astype(str).str.replace('$', '').str.replace(',', ''), errors='coerce').fillna(0)
    df[revenue_col] = pd.to_numeric(df[revenue_col].astype(str).str.replace('$', '').str.replace(',', ''), errors='coerce').fillna(0)
    
    # Create a temporary DataFrame with the metrics we need
    temp_df = pd.DataFrame({
        'PARTNER_NAME': df['PARTNER_NAME'],
        'QUERY': df['QUERY'],
        'REVENUE': df[revenue_col],
        'CLICKS': df[clicks_col],
        'RPC': df[rpc_col]
    })
    
    # Filter by selected partners
    temp_df = temp_df[temp_df['PARTNER_NAME'].isin(selected_partners)]
    
    # Group by keyword to find duplicates
    duplicates = temp_df.groupby('QUERY').agg({
        'PARTNER_NAME': lambda x: ', '.join(sorted(x)),
        'REVENUE': 'sum',
        'CLICKS': 'sum',
        'RPC': lambda x: sum(x) / len(x)  # Average RPC
    }).reset_index()
    
    # Filter for keywords used by multiple partners
    duplicates = duplicates[duplicates['PARTNER_NAME'].str.contains(',')]
    
    if not duplicates.empty:
        # Rename columns to match the format of top performers
        duplicates_df = duplicates.rename(columns={
            'QUERY': 'Keyword',
            'PARTNER_NAME': 'Partners',
            'REVENUE': 'Revenue',
            'CLICKS': 'Total Clicks',
            'RPC': 'Avg RPC'
        })
        
        # Reorder columns
        duplicates_df = duplicates_df[['Keyword', 'Partners', 'Revenue', 'Total Clicks', 'Avg RPC']]
        
        # Sort by Revenue (descending)
        duplicates_df = duplicates_df.sort_values('Revenue', ascending=False)
        return duplicates_df
    return None

def get_top_performers(df, selected_date, revenue_cols, rpc_cols, clicks_cols, selected_partners, min_clicks):
    # Get the index from the selected date
    day_index = int(selected_date.split()[1]) - 1
    
    # Get the corresponding columns for this index
    revenue_col = revenue_cols[day_index]
    rpc_col = rpc_cols[day_index]
    clicks_col = clicks_cols[day_index]
    
    # Filter by selected partners
    if selected_partners:
        df = df[df['PARTNER_NAME'].isin(selected_partners)]
    
    # Clean and convert data
    df[revenue_col] = pd.to_numeric(df[revenue_col].astype(str).str.replace('$', '').str.replace(',', ''), errors='coerce').fillna(0)
    df[clicks_col] = pd.to_numeric(df[clicks_col].astype(str).str.replace(',', ''), errors='coerce').fillna(0)
    df[rpc_col] = pd.to_numeric(df[rpc_col].astype(str).str.replace('$', '').str.replace(',', ''), errors='coerce').fillna(0)
    
    # Create clean dataframe
    clean_df = pd.DataFrame({
        'Keyword': df['QUERY'],
        'Partner': df['PARTNER_NAME'],
        'Revenue': df[revenue_col],
        'Clicks': df[clicks_col],
        'RPC': df[rpc_col]
    })
    
    # Remove rows containing 'Total'
    clean_df = clean_df[~clean_df['Keyword'].str.contains('Total', case=False, na=False)]
    
    # Find duplicate keywords
    duplicate_keywords = clean_df.groupby('Keyword').Partner.nunique()
    duplicate_keywords = set(duplicate_keywords[duplicate_keywords > 1].index)
    
    # Remove duplicate keywords from clean_df
    clean_df = clean_df[~clean_df['Keyword'].isin(duplicate_keywords)]
    
    # Apply minimum clicks filter
    clean_df = clean_df[clean_df['Clicks'] >= min_clicks]
    
    if clean_df.empty:
        st.warning(f"No unique keywords found with {min_clicks} or more clicks. Try lowering the minimum clicks filter.")
        return None, None, None
    
    # Get top performers with consistent column order
    column_order = ['Keyword', 'Partner', 'Revenue', 'Clicks', 'RPC']
    top_revenue = clean_df.nlargest(10, 'Revenue')[column_order]
    top_clicks = clean_df.nlargest(10, 'Clicks')[column_order]
    top_rpc = clean_df.nlargest(10, 'RPC')[column_order]
    
    return top_revenue, top_clicks, top_rpc

def analyze_keyword_trends(df, selected_date, revenue_cols, rpc_cols, clicks_cols, selected_partners):
    # Get the index from the selected date
    day_index = int(selected_date.split()[1]) - 1
    
    # Get the corresponding columns for this index
    revenue_col = revenue_cols[day_index]
    rpc_col = rpc_cols[day_index]
    clicks_col = clicks_cols[day_index]
    
    # Clean and convert data
    df[revenue_col] = pd.to_numeric(df[revenue_col].astype(str).str.replace('$', '').str.replace(',', ''), errors='coerce').fillna(0)
    df[clicks_col] = pd.to_numeric(df[clicks_col].astype(str).str.replace(',', ''), errors='coerce').fillna(0)
    df[rpc_col] = pd.to_numeric(df[rpc_col].astype(str).str.replace('$', '').str.replace(',', ''), errors='coerce').fillna(0)
    
    # Filter by selected partners
    if selected_partners:
        df = df[df['PARTNER_NAME'].isin(selected_partners)]
    
    # Create a list of all words from keywords
    all_words = []
    for keyword in df['QUERY'].str.lower():
        # Split keyword into words
        words = re.findall(r'\b\w+\b', keyword)
        for word in words:
            if len(word) > 2:  # Only consider words longer than 2 characters
                all_words.append(word)
    
    # Get the most common words
    from collections import Counter
    common_words = Counter(all_words).most_common(20)
    
    # Analyze performance for each common word
    trend_rows = []
    for word, count in common_words:
        # Get keywords containing this word
        mask = df['QUERY'].str.lower().str.contains(r'\b' + word + r'\b', regex=True)
        word_keywords = df[mask]
        
        if not word_keywords.empty:
            avg_revenue = word_keywords[revenue_col].mean()
            avg_clicks = word_keywords[clicks_col].mean()
            avg_rpc = word_keywords[rpc_col].mean()
            total_keywords = len(word_keywords)
            
            trend_rows.append({
                'Common Word': word,
                'Occurrences': total_keywords,
                'Avg Revenue': avg_revenue,
                'Avg Clicks': avg_clicks,
                'Avg RPC': avg_rpc,
                'Example Keywords': ', '.join(word_keywords['QUERY'].head(3).tolist())
            })
    
    if trend_rows:
        trends_df = pd.DataFrame(trend_rows)
        trends_df = trends_df.sort_values('Avg Revenue', ascending=False)
        return trends_df
    return None

def main():
    st.title("Top Performing Keywords")
    
    uploaded_file = st.file_uploader("Choose your Excel file", type=['xlsx', 'xls'])
    
    if uploaded_file is not None:
        try:
            # Read the Excel file with explicit dtype for string columns
            df = pd.read_excel(
                uploaded_file,
                dtype={
                    'PARTNER_NAME': str,
                    'Unnamed: 0': str,
                    'QUERY': str,
                    'Unnamed: 1': str
                }
            )
            
            # Process the data and get dates and partners
            df, dates, revenue_cols, rpc_cols, clicks_cols, partners = analyze_keywords(df)
            
            # Create filters
            col1, col2, col3 = st.columns([3, 1, 1])
            
            with col1:
                selected_partners = st.multiselect(
                    "Select Partners",
                    partners,
                    default=partners[:5] if len(partners) > 5 else partners
                )
            
            with col2:
                selected_date = st.selectbox("Select Date", dates, index=len(dates)-1)
            
            with col3:
                min_clicks = st.number_input(
                    "Minimum Clicks",
                    min_value=0,
                    value=30,
                    step=10,
                    help="Filter keywords by minimum number of clicks"
                )
            
            # Show keyword trends if any partners are selected
            if selected_partners:
                trends_df = analyze_keyword_trends(df, selected_date, revenue_cols, rpc_cols, clicks_cols, selected_partners)
                if trends_df is not None:
                    st.subheader("Keyword Trends Analysis")
                    st.write("Common words in keywords and their performance metrics:")
                    
                    # Create three columns for different sorting options
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        if st.button("Sort by Revenue"):
                            trends_df = trends_df.sort_values('Avg Revenue', ascending=False)
                    
                    with col2:
                        if st.button("Sort by Clicks"):
                            trends_df = trends_df.sort_values('Avg Clicks', ascending=False)
                    
                    with col3:
                        if st.button("Sort by RPC"):
                            trends_df = trends_df.sort_values('Avg RPC', ascending=False)
                    
                    st.dataframe(
                        trends_df.style.format({
                            'Avg Revenue': '${:,.2f}',
                            'Avg Clicks': '{:,.1f}',
                            'Avg RPC': '${:.2f}',
                            'Occurrences': '{:,.0f}'
                        }),
                        use_container_width=True,
                        hide_index=True
                    )
            
            # Show duplicate keywords section
            if selected_partners:
                duplicates_df = find_duplicate_keywords(df, selected_date, revenue_cols, rpc_cols, clicks_cols, selected_partners)
                if duplicates_df is not None:
                    st.subheader("Duplicate Keywords")
                    st.write("Keywords being used by multiple partners:")
                    st.dataframe(
                        duplicates_df.style.format({
                            'Revenue': '${:,.2f}',
                            'Total Clicks': '{:,.0f}',
                            'Avg RPC': '${:.2f}'
                        }),
                        use_container_width=True,
                        hide_index=True
                    )
            
            if st.button("Show Top Performers"):
                try:
                    top_revenue, top_clicks, top_rpc = get_top_performers(
                        df, selected_date, revenue_cols, rpc_cols, clicks_cols, 
                        selected_partners, min_clicks
                    )
                    
                    if top_revenue is not None:  # Only show results if we have data
                        # Display results in tabs
                        tab1, tab2, tab3 = st.tabs(["Top Revenue", "Top Clicks", "Top RPC"])
                        
                        with tab1:
                            st.subheader(f"Top 10 Unique Keywords by Revenue ({selected_date}, Min. Clicks: {min_clicks})")
                            st.write("Showing only keywords that are unique to a single partner")
                            st.dataframe(
                                top_revenue.style.format({
                                    'Revenue': '${:,.2f}',
                                    'RPC': '${:,.2f}',
                                    'Clicks': '{:,.0f}'
                                }),
                                use_container_width=True,
                                hide_index=True
                            )
                        
                        with tab2:
                            st.subheader(f"Top 10 Unique Keywords by Clicks ({selected_date}, Min. Clicks: {min_clicks})")
                            st.write("Showing only keywords that are unique to a single partner")
                            st.dataframe(
                                top_clicks.style.format({
                                    'Revenue': '${:,.2f}',
                                    'RPC': '${:,.2f}',
                                    'Clicks': '{:,.0f}'
                                }),
                                use_container_width=True,
                                hide_index=True
                            )
                        
                        with tab3:
                            st.subheader(f"Top 10 Unique Keywords by RPC ({selected_date}, Min. Clicks: {min_clicks})")
                            st.write("Showing only keywords that are unique to a single partner")
                            st.dataframe(
                                top_rpc.style.format({
                                    'Revenue': '${:,.2f}',
                                    'RPC': '${:,.2f}',
                                    'Clicks': '{:,.0f}'
                                }),
                                use_container_width=True,
                                hide_index=True
                            )
                        
                        # Add download button
                        combined_results = pd.concat([
                            top_revenue.assign(Category='Top Revenue', Date=selected_date),
                            top_clicks.assign(Category='Top Clicks', Date=selected_date),
                            top_rpc.assign(Category='Top RPC', Date=selected_date)
                        ])
                        
                        csv = combined_results.to_csv(index=False)
                        st.download_button(
                            label="Download Results",
                            data=csv,
                            file_name=f"top_keywords_{selected_date}.csv",
                            mime="text/csv"
                        )
                    
                except Exception as e:
                    st.error(f"Error processing data: {str(e)}")
                    st.write("Available columns:", list(df.columns))
                
        except Exception as e:
            st.error(f"Error reading file: {str(e)}")
            st.write("Please make sure your Excel file is properly formatted with the required columns.")

if __name__ == "__main__":
    main() 