# Keyword Analysis Tool - Simple Setup Guide

## First Time Setup (You only do this once!)

1. Install Python:
   - Go to https://www.python.org/downloads/
   - Click the big yellow "Download Python" button
   - Run the installer
   - ✨ Important: Check the box that says "Add Python to PATH" during installation!

2. Set up the tool:
   - Open Command Prompt (Windows) or Terminal (Mac)
     * Windows: Press the Windows key, type "cmd", press Enter
     * Mac: Press Command + Space, type "terminal", press Enter
   
   - Copy and paste these commands (press Enter after each):
   ```
   cd Desktop/keyword_tool
   python -m venv venv
   ```
   
   Then:
   * For Windows, type:
   ```
   venv\Scripts\activate
   pip install -r requirements.txt
   ```
   
   * For Mac, type:
   ```
   source venv/bin/activate
   pip install -r requirements.txt
   ```

## Using the Tool (Every time you want to use it)

1. Open Command Prompt/Terminal (same as step 2 above)

2. Type these commands:
   * For Windows:
   ```
   cd Desktop/keyword_tool
   venv\Scripts\activate
   streamlit run keyword_analyzer.py
   ```

   * For Mac:
   ```
   cd Desktop/keyword_tool
   source venv/bin/activate
   streamlit run keyword_analyzer.py
   ```

3. The tool will open in your web browser!

4. To use it:
   - Click "Browse files" to upload your Excel file
   - Pick your partners
   - Choose a date
   - Click "Show Top Performers"

## Need Help?
Contact: [your email/phone]

💡 Tip: Save this folder on your Desktop for easy access! 